package com.example.android.popularmovies;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.android.popularmovies.Utils.NetworkUtils;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

import static com.example.android.popularmovies.R.drawable.ic_favorite_black_24dp;

public class MovieDetail extends AppCompatActivity implements TrailerAdapter.ListItemClickListener{

    int id;
    String BASE_IMAGE_PATH= "http://image.tmdb.org/t/p/w342//";
    String temporary_poster_path;
    String complete_poster_path;
    TextView movie_title;
    ImageView movie_poster;
    TextView movie_release_date;
    TextView movie_rating;
    TextView movie_description;
    RecyclerView recyclerViewTrailers;
    RecyclerView recyclerViewReviews;
    TrailerAdapter mAdapter;
    ReviewAdapter reviewAdapter;
    String release_date;
    String overview;
    String original_title;
    Boolean isMovieAvailable = false;
    Double vote_average;
    TextView noReview, noTrailer;
    ProgressBar progress_trailer, progress_review;
    Button button_favourites;
    String poster_path;
    public ArrayList<Trailer> trailerArrayList = new ArrayList<Trailer>();
    public ArrayList<Review> reviewArrayList = new ArrayList<Review>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);
        progress_review = (ProgressBar)findViewById(R.id.progress_review);
        progress_trailer = (ProgressBar)findViewById(R.id.progress_trailer);
        noTrailer = (TextView)findViewById(R.id.no_trailer);
        noReview = (TextView)findViewById(R.id.no_review);
        Intent intent = getIntent();
        id = intent.getIntExtra("id", -88);
        vote_average = intent.getDoubleExtra("vote_average", -999.999);
        original_title = intent.getStringExtra("original_title");
        overview = intent.getStringExtra("overview");
        poster_path = intent.getStringExtra("poster_path");
        release_date = intent.getStringExtra("release_date");
        temporary_poster_path = poster_path;
        complete_poster_path = BASE_IMAGE_PATH + temporary_poster_path;

        movie_title = (TextView)findViewById(R.id.movie_title);
        movie_poster = (ImageView) findViewById(R.id.movie_poster);
        movie_release_date = (TextView)findViewById(R.id.movie_release_date);
        movie_rating = (TextView)findViewById(R.id.moving_rating);
        movie_description = (TextView)findViewById(R.id.movie_description);

        movie_title.setText(original_title);
        Picasso.with(this).load(complete_poster_path).into(movie_poster);
        movie_release_date.setText(release_date);
        movie_rating.setText(vote_average+"");
        movie_description.setText(overview);

        CheckIsMovieAvailable checkIsMovieAvailable = new CheckIsMovieAvailable();
        checkIsMovieAvailable.execute();
        button_favourites = (Button)findViewById(R.id.button);

        recyclerViewTrailers = (RecyclerView) findViewById(R.id.recycler_view_trailers);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerViewTrailers.setLayoutManager(mLayoutManager);
        recyclerViewTrailers.setItemAnimator(new DefaultItemAnimator());
        recyclerViewTrailers.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        mAdapter = new TrailerAdapter(this, getApplicationContext(), trailerArrayList);
        recyclerViewTrailers.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();

        recyclerViewReviews = (RecyclerView) findViewById(R.id.recycler_view_reviews);
        RecyclerView.LayoutManager mLayoutManager1 = new LinearLayoutManager(getApplicationContext());
        recyclerViewReviews.setLayoutManager(mLayoutManager1);
        recyclerViewReviews.setItemAnimator(new DefaultItemAnimator());
        recyclerViewReviews.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        reviewAdapter = new ReviewAdapter(reviewArrayList);
        recyclerViewReviews.setAdapter(reviewAdapter);
        reviewAdapter.notifyDataSetChanged();

        if(!isMovieAvailable||true){
            FetchVideosData fetchVideosData = new FetchVideosData();
            String address = NetworkUtils.videosDetailsQuery(id);
            fetchVideosData.execute(address);
            //prepareTrailerData();

            FetchReviewsData fetchReviewsData = new FetchReviewsData();
            String review_address = NetworkUtils.reviewsDetailsQuery(id);
            fetchReviewsData.execute(review_address);
        }
        else{
            trailerArrayList.clear();
            trailerArrayList = DatabaseUtils.getTrailers(this, id);
            mAdapter = new TrailerAdapter(MovieDetail.this, getApplicationContext(), trailerArrayList);
            recyclerViewTrailers.setAdapter(mAdapter);
            mAdapter.notifyDataSetChanged();
            if(trailerArrayList.isEmpty()){
                showNoTrailer();
            }
            else{
                showTrailer();
            }


            reviewArrayList.clear();
            reviewArrayList = DatabaseUtils.getReviews(this, id);
            reviewAdapter = new ReviewAdapter(reviewArrayList);
            recyclerViewReviews.setAdapter(reviewAdapter);
            reviewAdapter.notifyDataSetChanged();
            if(reviewArrayList.isEmpty()){
                showNoReview();
            }
            else {
                showReview();
            }
        }
    }

    public void button_clicked(View view, String key) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+key));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
    private void prepareTrailerData() {
        Trailer trailer = new Trailer("Mad Max: Fury Road", "Action & Adventure", "2015");
        trailerArrayList.add(trailer);
        trailer = new Trailer("Mad Max: Fury Road", "Action & Adventure", "2015");
        trailerArrayList.add(trailer);
    }

    private void prepareReviewData() {
        Review review = new Review("Mad Max: Fury Road", "Action & Adventure", "2015");
        reviewArrayList.add(review);
        review = new Review("Mad Max: Fury Road", "Action & Adventure", "2015");
        reviewArrayList.add(review);
    }

    public void showNoReview(){
        recyclerViewReviews.setVisibility(View.INVISIBLE);
        noReview.setVisibility(View.VISIBLE);
    }

    public void showReview(){
        recyclerViewReviews.setVisibility(View.VISIBLE);
        noReview.setVisibility(View.INVISIBLE);
    }

    public void showNoTrailer(){
        recyclerViewTrailers.setVisibility(View.INVISIBLE);
        noTrailer.setVisibility(View.VISIBLE);
    }

    public void showTrailer(){
        recyclerViewTrailers.setVisibility(View.VISIBLE);
        noTrailer.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onListItemClick(String key) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:"+key));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }



    public void action_favourites(View view) {
        if(isMovieAvailable){
            button_favourites.setBackgroundResource(R.drawable.ic_favorite_border_black_24dp);
            DeleteAsyncTask deleteAsyncTask = new DeleteAsyncTask();
            deleteAsyncTask.execute();
        }
        else{
            button_favourites.setBackgroundResource(R.drawable.ic_favorite_black_24dp);
            InsertAsyncTask insertAsyncTask = new InsertAsyncTask();
            insertAsyncTask.execute();
        }

    }

    public class FetchReviewsData extends AsyncTask<String, Void, String>{
        URL url = null;
        String response = "";

        @Override
        protected void onPreExecute() {
            progress_review.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... strings) {
            String address = strings[0];
            try {
                url = new URL(address);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            try {
                response = NetworkUtils.getResponseFromHttpUrl(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String response) {
            super.onPostExecute(response);
            progress_review.setVisibility(View.INVISIBLE);
            if(!response.equals("")){
                //Before final dynamic working just uncomment below line and comment next to next line.
                //prepareReviewData();
                //reviewAdapter.notifyDataSetChanged();
                reviewArrayList.clear();
                reviewArrayList = NetworkUtils.getReviewAfterParsing(response);
                reviewAdapter = new ReviewAdapter(reviewArrayList);
                recyclerViewReviews.setAdapter(reviewAdapter);
                reviewAdapter.notifyDataSetChanged();
                if(reviewArrayList.isEmpty()){
                    showNoReview();
                }
                else {
                    showReview();
                }
            }
            else{
                noReview.setText("No Internet Connection!");
                showNoReview();
            }
        }
    }

    public class FetchVideosData extends AsyncTask<String, Void, String>{
        URL url = null;
        String response = "";

        @Override
        protected void onPreExecute() {
            progress_trailer.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... strings) {
            String address = strings[0];
            try {
                url = new URL(address);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            try {
                response = NetworkUtils.getResponseFromHttpUrl(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        @Override
        protected void onPostExecute(String response) {
            super.onPostExecute(response);
            progress_trailer.setVisibility(View.INVISIBLE);
            if(!response.equals("")){
                //Before final dynamic working just uncomment below line and comment next to next line.
                //prepareTrailerData();
                //mAdapter.notifyDataSetChanged();
                trailerArrayList.clear();
                trailerArrayList = NetworkUtils.getTrailerAfterParsing(response);
                mAdapter = new TrailerAdapter(MovieDetail.this, getApplicationContext(), trailerArrayList);
                recyclerViewTrailers.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();
                if(trailerArrayList.isEmpty()){
                    showNoTrailer();
                }
                else{
                    showTrailer();
                }

            }
            else{
                noTrailer.setText("No Internet Connection!");
                showNoTrailer();
            }
        }
    }
    public class InsertAsyncTask extends AsyncTask<Void, Void, Void>{

        @Override
        protected Void doInBackground(Void... voids) {
            DatabaseUtils.passData(getApplicationContext(), trailerArrayList, reviewArrayList, id, vote_average, original_title, overview, release_date, temporary_poster_path);
            return null;
        }
    }
    public class DeleteAsyncTask extends AsyncTask<Void, Void, Void>{

        @Override
        protected Void doInBackground(Void... voids) {
            DatabaseUtils.deleteMovie(getApplicationContext(), trailerArrayList, reviewArrayList, id);
            return null;
        }
    }
    public class CheckIsMovieAvailable extends AsyncTask<Void, Void, Boolean>{

        @Override
        protected Boolean doInBackground(Void... voids) {
            boolean movie_avail = DatabaseUtils.checkMovieInDatabase(getApplicationContext(), id);
            return movie_avail;
        }

        @Override
        protected void onPostExecute(Boolean movie_avail) {
            isMovieAvailable = movie_avail;
            if(isMovieAvailable){
                button_favourites.setBackgroundResource(R.drawable.ic_favorite_black_24dp);
            }

        }
    }
}