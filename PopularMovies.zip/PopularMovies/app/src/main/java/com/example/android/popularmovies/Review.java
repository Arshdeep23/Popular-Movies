package com.example.android.popularmovies;

/**
 * Created by Arshdeep on 1/5/2018.
 */

public class Review {
    public String author = "";
    public String content = "";
    public String id;
    public Review(String author, String content, String id){
        this.author = author;
        this.content = content;
        this.id = id;
    }

    public String getAuthor() {
        return author;
    }

    public String getContent() {
        return content;
    }

    public String getId() {
        return id;
    }
}
