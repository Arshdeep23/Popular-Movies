package com.example.android.popularmovies;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Arshdeep on 1/5/2018.
 */

public class TrailerAdapter extends RecyclerView.Adapter<TrailerAdapter.TrailerHolder> {
    Context context;
    public ArrayList<Trailer> trailerArrayList= new ArrayList<Trailer>();
    final private ListItemClickListener mOnClickListener;
    public interface ListItemClickListener{
        void onListItemClick(String key);
    }

    public TrailerAdapter(ListItemClickListener onCLickListener, Context context, ArrayList<Trailer> trailerArrayList){
        this.trailerArrayList = trailerArrayList;
        this.context = context;
        this.mOnClickListener = onCLickListener;
    }

    public class TrailerHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        TextView name;

        public TrailerHolder(View itemView) {
            super(itemView);
            name = (TextView)itemView.findViewById(R.id.trailer_name_textview);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int adapterPosition = getAdapterPosition();
            String key = trailerArrayList.get(adapterPosition).getTrailer_key();
            mOnClickListener.onListItemClick(key);
        }
    }

    @Override
    public TrailerHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.trailer_item, parent, false);

        return new TrailerHolder(itemView);
    }

    @Override
    public void onBindViewHolder(TrailerHolder holder, int position) {
        Trailer trailer = trailerArrayList.get(position);
        int show_position = position + 1;
        holder.name.setText(context.getString(R.string.trailer_label)+ show_position + "");
    }

    @Override
    public int getItemCount() {
        if(trailerArrayList==null){
            return 0;
        }
        return trailerArrayList.size();
    }
}
