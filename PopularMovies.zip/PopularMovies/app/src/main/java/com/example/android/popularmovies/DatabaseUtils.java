package com.example.android.popularmovies;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.widget.Toast;

import com.example.android.popularmovies.Data.MovieContract;
import com.example.android.popularmovies.Data.MoviesContentProvider;
import com.example.android.popularmovies.Data.MoviesDbHelper;

import java.util.ArrayList;

/**
 * Created by Arshdeep on 1/7/2018.
 */

public class DatabaseUtils {
    static SQLiteDatabase mDB;
    static Toast toast;

    public static void passData(Context context, ArrayList<Trailer> trailerArrayList, ArrayList<Review> reviewArrayList, int id, Double vote_average, String original_title, String overview, String release_date, String complete_poster_path){
        //MoviesDbHelper moviesDbHelper= new MoviesDbHelper(context);
        //mDB = moviesDbHelper.getWritableDatabase();

        Uri uri;
        ContentValues contentValues = new ContentValues();
        contentValues.put(MovieContract.MovieEntry.COLUMN_ORIGINAL_TITLE, original_title);
        contentValues.put(MovieContract.MovieEntry.COLUMN_OVERVIEW, overview);
        contentValues.put(MovieContract.MovieEntry.COLUMN_RELEASE_DATE, release_date);
        contentValues.put(MovieContract.MovieEntry.COLUMN_POSTER_PATH, complete_poster_path);
        contentValues.put(MovieContract.MovieEntry.COLUMN_VOTE_AVERAGE, vote_average);
        contentValues.put(MovieContract.MovieEntry.COLUMN_ID, id);
        //mDB.insert(MovieContract.MovieEntry.TABLE_NAME, null, contentValues);
        uri = context.getContentResolver().insert(MovieContract.MovieEntry.CONTENT_URI, contentValues);
        //toast = new Toast(context);
        //toast.makeText(context, uri.toString(), Toast.LENGTH_LONG).show();

        ContentValues contentValues1;
        if(!trailerArrayList.isEmpty()){
            for(int i=0;i<trailerArrayList.size();i++){
                Trailer trailer = trailerArrayList.get(i);
                contentValues1 = new ContentValues();
                contentValues1.put(MovieContract.TrailerEntry.COLUMN_TRAILER_ID, trailer.getTrailer_id());
                contentValues1.put(MovieContract.TrailerEntry.COLUMN_TRAILER_NAME, trailer.getTrailer_name());
                contentValues1.put(MovieContract.TrailerEntry.COLUMN_TRAILER_KEY, trailer.getTrailer_key());
                //mDB.insert(MovieContract.TrailerEntry.TABLE_NAME, null, contentValues1);
                uri = context.getContentResolver().insert(MovieContract.TrailerEntry.CONTENT_URI, contentValues1);
                //toast = new Toast(context);
                //toast.makeText(context, uri.toString(), Toast.LENGTH_LONG).show();
            }
        }

        ContentValues contentValues2;
        if(!reviewArrayList.isEmpty()){
            for(int i=0;i<reviewArrayList.size();i++){
                Review review = reviewArrayList.get(i);
                contentValues2 = new ContentValues();
                contentValues2.put(MovieContract.ReviewEntry.COLUMN_REVIEW_AUTHOR, review.getAuthor());
                contentValues2.put(MovieContract.ReviewEntry.COLUMN_REVIEW_CONTENT, review.getContent());
                contentValues2.put(MovieContract.ReviewEntry.COLUMN_REVIEW_ID, review.getId());
                //mDB.insert(MovieContract.ReviewEntry.TABLE_NAME, null, contentValues2);
                uri = context.getContentResolver().insert(MovieContract.ReviewEntry.CONTENT_URI, contentValues2);
                //toast = new Toast(context);
                //toast.makeText(context, uri.toString(), Toast.LENGTH_LONG).show();
            }
        }
    }

    public static Cursor getMovieDetails(Context context){
        //MoviesDbHelper moviesDbHelper= new MoviesDbHelper(context);
        //mDB = moviesDbHelper.getReadableDatabase();
        String[] projection = {
                MovieContract.MovieEntry._ID,
                MovieContract.MovieEntry.COLUMN_ORIGINAL_TITLE,
                MovieContract.MovieEntry.COLUMN_OVERVIEW,
                MovieContract.MovieEntry.COLUMN_RELEASE_DATE,
                MovieContract.MovieEntry.COLUMN_POSTER_PATH,
                MovieContract.MovieEntry.COLUMN_VOTE_AVERAGE,
                MovieContract.MovieEntry.COLUMN_ID
        };
        Cursor cursor = context.getContentResolver().query(MovieContract.MovieEntry.CONTENT_URI, projection,null,null, MovieContract.MovieEntry._ID);
        //Cursor cursor = mDB.query(MovieContract.MovieEntry.TABLE_NAME, projection, null, null, null, null, MovieContract.MovieEntry._ID);
        return cursor;
    }

    public static ArrayList<Movies> cursorToArrayList(Cursor cursor){
        ArrayList<Movies> moviesArrayList = new ArrayList<Movies>();
        while (cursor.moveToNext()){
            String original_title = cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_ORIGINAL_TITLE));
            String overview = cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_OVERVIEW));
            String release_date = cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_RELEASE_DATE));
            String poster_path = cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_POSTER_PATH));
            Double vote_average = cursor.getDouble(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_VOTE_AVERAGE));
            int id = cursor.getInt(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_ID));
            moviesArrayList.add(new Movies(original_title, overview, release_date, poster_path, vote_average, id));
        }
        cursor.close();
        return moviesArrayList;
    }

    public static void deleteMovie(Context context, ArrayList<Trailer> trailerArrayList, ArrayList<Review> reviewArrayList, int id){
        MoviesDbHelper moviesDbHelper= new MoviesDbHelper(context);
        mDB = moviesDbHelper.getWritableDatabase();
        String selection = MovieContract.MovieEntry.COLUMN_ID + " LIKE ?";
        String[] selectionArgs = { id + "" };
        mDB.delete(MovieContract.MovieEntry.TABLE_NAME, selection, selectionArgs);
        //int no = context.getContentResolver().delete(MovieContract.MovieEntry.CONTENT_URI, selection, selectionArgs);
        selection = MovieContract.TrailerEntry.COLUMN_TRAILER_ID + " LIKE ?";
        mDB.delete(MovieContract.TrailerEntry.TABLE_NAME, selection, selectionArgs);
        //no = context.getContentResolver().delete(MovieContract.TrailerEntry.CONTENT_URI, selection, selectionArgs);
        selection = MovieContract.ReviewEntry.COLUMN_REVIEW_ID  + " LIKE ?";
        mDB.delete(MovieContract.ReviewEntry.TABLE_NAME, selection, selectionArgs);
        //no = context.getContentResolver().delete(MovieContract.ReviewEntry.CONTENT_URI, selection, selectionArgs);
    }

    public static boolean checkMovieInDatabase(Context context, int id){
        boolean isMovieAvailable = false;
        //MoviesDbHelper moviesDbHelper= new MoviesDbHelper(context);
        //mDB = moviesDbHelper.getReadableDatabase();
        String[] projection = {
                MovieContract.MovieEntry._ID,
                MovieContract.MovieEntry.COLUMN_ORIGINAL_TITLE,
                MovieContract.MovieEntry.COLUMN_OVERVIEW,
                MovieContract.MovieEntry.COLUMN_RELEASE_DATE,
                MovieContract.MovieEntry.COLUMN_POSTER_PATH,
                MovieContract.MovieEntry.COLUMN_VOTE_AVERAGE,
                MovieContract.MovieEntry.COLUMN_ID
        };
        String selection = MovieContract.MovieEntry.COLUMN_ID + " = ?";
        String[] selectionArgs = { id+"" };
        Cursor cursor = context.getContentResolver().query(MovieContract.MovieEntry.CONTENT_URI, projection, selection, selectionArgs, MovieContract.MovieEntry._ID);
        //Cursor cursor = mDB.query(MovieContract.MovieEntry.TABLE_NAME, projection, selection, selectionArgs, null, null, MovieContract.MovieEntry._ID);
        if(cursor.getCount()>0){
            isMovieAvailable = true;
        }
        return isMovieAvailable;
    }
    public static ArrayList<Trailer> getTrailers(Context context, int id){
        String[] projection = {
                MovieContract.TrailerEntry._ID,
                MovieContract.TrailerEntry.COLUMN_TRAILER_NAME,
                MovieContract.TrailerEntry.COLUMN_TRAILER_KEY,
                MovieContract.TrailerEntry.COLUMN_TRAILER_ID
        };
        String selection = MovieContract.TrailerEntry.COLUMN_TRAILER_ID + " = ?";
        String[] selectionArgs = { id+"" };
        Cursor cursor = context.getContentResolver().query(MovieContract.TrailerEntry.CONTENT_URI, projection, selection, selectionArgs, MovieContract.TrailerEntry._ID);

        ArrayList<Trailer> trailerListArray = new ArrayList<Trailer>();
        while (cursor.moveToNext()){
            String key = cursor.getString(cursor.getColumnIndex(MovieContract.TrailerEntry.COLUMN_TRAILER_KEY));
            String name = cursor.getString(cursor.getColumnIndex(MovieContract.TrailerEntry.COLUMN_TRAILER_NAME));
            int trailer_id = cursor.getInt(cursor.getColumnIndex(MovieContract.TrailerEntry.COLUMN_TRAILER_ID));
            trailerListArray.add(new Trailer(trailer_id+"", name, key));
        }
        cursor.close();
        return trailerListArray;
    }
    public static ArrayList<Review> getReviews(Context context, int id){
        String[] projection = {
                MovieContract.ReviewEntry._ID,
                MovieContract.ReviewEntry.COLUMN_REVIEW_ID,
                MovieContract.ReviewEntry.COLUMN_REVIEW_CONTENT,
                MovieContract.ReviewEntry.COLUMN_REVIEW_AUTHOR
        };
        String selection = MovieContract.ReviewEntry.COLUMN_REVIEW_ID+ " = ?";
        String[] selectionArgs = { id+"" };
        Cursor cursor = context.getContentResolver().query(MovieContract.ReviewEntry.CONTENT_URI, projection, selection, selectionArgs, MovieContract.TrailerEntry._ID);

        ArrayList<Review> reviewArrayList= new ArrayList<Review>();
        while (cursor.moveToNext()){
            String author = cursor.getString(cursor.getColumnIndex(MovieContract.ReviewEntry.COLUMN_REVIEW_AUTHOR));
            String content = cursor.getString(cursor.getColumnIndex(MovieContract.ReviewEntry.COLUMN_REVIEW_CONTENT));
            String review_id = cursor.getString(cursor.getColumnIndex(MovieContract.ReviewEntry.COLUMN_REVIEW_ID));
            reviewArrayList.add(new Review(author, content, review_id));
        }
        cursor.close();
        return reviewArrayList;
    }
}
