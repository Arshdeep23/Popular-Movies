package com.example.android.popularmovies;

/**
 * Created by Arshdeep on 1/5/2018.
 */

public class Trailer {
    public String trailer_id = "";
    public String trailer_name ="";
    public String trailer_key ="";

    public Trailer(String id, String name, String key){
        this.trailer_id = id;
        this.trailer_name = name;
        this.trailer_key = key ;
    }

    public String getTrailer_id() {
        return trailer_id;
    }

    public String getTrailer_name() {
        return trailer_name;
    }

    public String getTrailer_key() {
        return trailer_key;
    }
}
