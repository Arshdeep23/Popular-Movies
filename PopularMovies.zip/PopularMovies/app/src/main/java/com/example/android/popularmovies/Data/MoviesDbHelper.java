package com.example.android.popularmovies.Data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.android.popularmovies.Data.MovieContract.MovieEntry;
import com.example.android.popularmovies.Data.MovieContract.TrailerEntry;
import com.example.android.popularmovies.Data.MovieContract.ReviewEntry;
import com.example.android.popularmovies.Review;

/**
 * Created by Arshdeep on 1/7/2018.
 */

public class MoviesDbHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "movie_info.db";
    public static final int DATABASE_VERSION = 1;
    public MoviesDbHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String SQL_CREATE_MOVIES_TABLE = "CREATE TABLE " +
                MovieEntry.TABLE_NAME + "(" +
                MovieEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                MovieEntry.COLUMN_ORIGINAL_TITLE + " TEXT NOT NULL, " +
                MovieEntry.COLUMN_OVERVIEW + " TEXT NOT NULL, " +
                MovieEntry.COLUMN_RELEASE_DATE + " TEXT NOT NULL, " +
                MovieEntry.COLUMN_POSTER_PATH + " TEXT NOT NULL, " +
                MovieEntry.COLUMN_VOTE_AVERAGE + " REAL NOT NULL, " +
                MovieEntry.COLUMN_ID + " INTEGER NOT NULL " +
                ");";
        db.execSQL(SQL_CREATE_MOVIES_TABLE);
        String SQL_CREATE_TRAILERS_TABLE = "CREATE TABLE " +
                TrailerEntry.TABLE_NAME + "(" +
                TrailerEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                TrailerEntry.COLUMN_TRAILER_ID + " TEXT NOT NULL, " +
                TrailerEntry.COLUMN_TRAILER_NAME + " TEXT NOT NULL, " +
                TrailerEntry.COLUMN_TRAILER_KEY + " TEXT NOT NULL " +
                ");";
        db.execSQL(SQL_CREATE_TRAILERS_TABLE);
        String SQL_CREATE_REVIEWS_TABLE = "CREATE TABLE " +
                ReviewEntry.TABLE_NAME + "(" +
                ReviewEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ReviewEntry.COLUMN_REVIEW_ID + " INTEGER NOT NULL, " +
                ReviewEntry.COLUMN_REVIEW_AUTHOR + " TEXT NOT NULL, " +
                ReviewEntry.COLUMN_REVIEW_CONTENT + " TEXT NOT NULL " +
                ");";
        db.execSQL(SQL_CREATE_REVIEWS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ MovieEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+ TrailerEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+ ReviewEntry.TABLE_NAME);
        onCreate(db);
    }
}