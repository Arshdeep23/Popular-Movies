package com.example.android.popularmovies;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Arshdeep on 1/5/2018.
 */

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ReviewHolder> {

    public ArrayList<Review> reviewArrayList;
    public class ReviewHolder extends RecyclerView.ViewHolder{
        TextView author, content;

        public ReviewHolder(View itemView) {
            super(itemView);
            author = (TextView)itemView.findViewById(R.id.review_author_textview);
            content = (TextView)itemView.findViewById(R.id.review_content_textview);
        }
    }

    @Override
    public ReviewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.review_item, parent, false);

        return new ReviewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ReviewHolder holder, int position) {
        Review review = reviewArrayList.get(position);
        holder.content.setText(review.getContent());
        holder.author.setText(review.getAuthor());
    }

    @Override
    public int getItemCount() {
        if(reviewArrayList==null){
            return 0;
        }
        return reviewArrayList.size();
    }

    public ReviewAdapter(ArrayList<Review> reviewArrayList){
        this.reviewArrayList = reviewArrayList;
    }
}
