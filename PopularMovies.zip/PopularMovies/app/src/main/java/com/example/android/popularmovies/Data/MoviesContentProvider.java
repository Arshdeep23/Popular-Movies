package com.example.android.popularmovies.Data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import static com.example.android.popularmovies.Data.MovieContract.MovieEntry.TABLE_NAME;

/**
 * Created by Arshdeep on 1/8/2018.
 */

public class MoviesContentProvider extends ContentProvider {

    MoviesDbHelper DbHelper;
    SQLiteDatabase mDB;
    public static final int MOVIE = 100;
    public static final int MOVIE_WITH_ID = 101;
    public static final int TRAILER = 200;
    public static final int TRAILER_WITH_ID = 201;
    public static final int REVIEW = 300;
    public static final int REVIEW_WITH_ID = 301;

    public static final UriMatcher sUriMatcher = buildUriMatcher();

    static UriMatcher buildUriMatcher(){
        UriMatcher sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        sUriMatcher.addURI(MovieContract.CONTENT_AUTHORITY,MovieContract.PATH_MOVIES,MOVIE);
        sUriMatcher.addURI(MovieContract.CONTENT_AUTHORITY,MovieContract.PATH_MOVIES + "/#",MOVIE_WITH_ID);
        sUriMatcher.addURI(MovieContract.CONTENT_AUTHORITY,MovieContract.PATH_TRAILERS,TRAILER);
        sUriMatcher.addURI(MovieContract.CONTENT_AUTHORITY,MovieContract.PATH_TRAILERS+ "/#",TRAILER_WITH_ID);
        sUriMatcher.addURI(MovieContract.CONTENT_AUTHORITY,MovieContract.PATH_REVIEWS,REVIEW);
        sUriMatcher.addURI(MovieContract.CONTENT_AUTHORITY,MovieContract.PATH_REVIEWS + "/#",REVIEW_WITH_ID);

        return sUriMatcher;
    }

    @Override
    public boolean onCreate() {
        DbHelper = new MoviesDbHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        mDB = DbHelper.getReadableDatabase();
        int match = sUriMatcher.match(uri);
        Cursor cursor;
        switch (match){
            case MOVIE:
                cursor = mDB.query(TABLE_NAME,projection,selection,selectionArgs,null,null,sortOrder);
                return cursor;
            case TRAILER:
                cursor = mDB.query(MovieContract.TrailerEntry.TABLE_NAME,projection,selection,selectionArgs,null,null,sortOrder);
                return cursor;
            case REVIEW:
                cursor = mDB.query(MovieContract.ReviewEntry.TABLE_NAME,projection,selection,selectionArgs,null,null,sortOrder);
                return cursor;
            default:
                throw new UnsupportedOperationException("Unknown uri: "+uri);
        }
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        mDB = DbHelper.getWritableDatabase();
        int match = sUriMatcher.match(uri);
        Uri returnUri;
        long id;
        switch (match){
            case MOVIE_WITH_ID:
                id = mDB.insert(TABLE_NAME, null, contentValues);
                if(id>0){
                    returnUri = ContentUris.withAppendedId(uri,id);
                }
                else{
                    throw new android.database.SQLException("Failed to insert into Uri: " + uri);
                }
                break;
            case MOVIE:
                //String id = uri.getPathSegments().get(1);
                //
                // String selection = MovieContract.MovieEntry.COLUMN_ID + " LIKE ?";
                id = mDB.insert(TABLE_NAME, null, contentValues);
                if(id>0){
                    returnUri = ContentUris.withAppendedId(uri,id);
                }
                else{
                    throw new android.database.SQLException("Failed to insert into Uri: " + uri);
                }
                break;
            case TRAILER_WITH_ID:
                id = mDB.insert(MovieContract.TrailerEntry.TABLE_NAME, null, contentValues);
                if(id>0){
                    returnUri = ContentUris.withAppendedId(uri,id);
                }
                else{
                    throw new android.database.SQLException("Failed to insert into Uri: " + uri);
                }
                break;
            case TRAILER:
                id = mDB.insert(MovieContract.TrailerEntry.TABLE_NAME, null, contentValues);
                if(id>0){
                    returnUri = ContentUris.withAppendedId(uri,id);
                }
                else{
                    throw new android.database.SQLException("Failed to insert into Uri: " + uri);
                }
                break;
            case REVIEW_WITH_ID:
                id = mDB.insert(MovieContract.ReviewEntry.TABLE_NAME, null, contentValues);
                if(id>0){
                    returnUri = ContentUris.withAppendedId(uri,id);
                }
                else{
                    throw new android.database.SQLException("Failed to insert into Uri: " + uri);
                }
                break;
            case REVIEW:
                id = mDB.insert(MovieContract.ReviewEntry.TABLE_NAME, null, contentValues);
                if(id>0){
                    returnUri = ContentUris.withAppendedId(uri,id);
                }
                else{
                    throw new android.database.SQLException("Failed to insert into Uri: " + uri);
                }
                break;
            default:throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri,null);
        return returnUri;
    }


    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        mDB = DbHelper.getReadableDatabase();
        int match = sUriMatcher.match(uri);
        int deletedItems = 0;
        String id;
        switch (match){
            case MOVIE_WITH_ID:
                id = uri.getPathSegments().get(1);
                deletedItems = mDB.delete(MovieContract.MovieEntry.TABLE_NAME, selection, selectionArgs);
                break;
            case TRAILER_WITH_ID:
                id = uri.getPathSegments().get(1);
                deletedItems = mDB.delete(MovieContract.TrailerEntry.TABLE_NAME, selection,selectionArgs);
                break;
            case REVIEW_WITH_ID:
                id = uri.getPathSegments().get(1);
                deletedItems = mDB.delete(MovieContract.ReviewEntry.TABLE_NAME, selection, selectionArgs);
                break;
        }
        if (deletedItems != 0) {
            // A task was deleted, set notification
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return deletedItems;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }
}
